# main.py
from getpass import getpass
import os
import auth
import encryption
import storage
import json

# Establece la ruta del archivo donde se almacenan los datos. Asegúrate de que este archivo esté correctamente cifrado.
DATA_FILE = 'vault.json'
KEY_FILE = 'vault.key'

def initialize_system():
    """Inicializa el sistema comprobando si existe una clave de cifrado y la base de datos. Si no, los crea."""
    if not os.path.exists(KEY_FILE):
        key = encryption.generate_key()
        with open(KEY_FILE, 'wb') as key_file:
            key_file.write(key)
        storage.save_data(DATA_FILE, encrypt_data(key, '{}'))  # Guarda un JSON vacío cifrado como inicio.

def load_or_create_vault(key):
    """Carga o crea el vault de contenedores."""
    encrypted_data = storage.load_data(DATA_FILE)
    if encrypted_data is None:
        return {}
    try:
        decrypted_data = encryption.decrypt_data(key, encrypted_data)
        return json.loads(decrypted_data)
    except Exception as e:
        print(f"Error al descifrar el vault: {e}")
        return None

def encrypt_data(key, data):
    """Cifra los datos usando la clave proporcionada."""
    return encryption.encrypt_data(key, data)

def decrypt_data(key, encrypted_data):
    """Descifra los datos usando la clave proporcionada."""
    return encryption.decrypt_data(key, encrypted_data)

def main():
    initialize_system()
    
    # Carga la clave de cifrado
    with open(KEY_FILE, 'rb') as key_file:
        key = key_file.read()

    print("Bienvenido a SecureBox")
    # Simulación de proceso de autenticación
    password = getpass("Por favor, introduce tu contraseña para acceder: ")

    # Verificar la contraseña con alguna función de auth.py
    if not auth.verify_password(password):
        print("Contraseña incorrecta.")
        return

    vault = load_or_create_vault(key)
    if vault is None:
        print("No se pudo cargar el vault.")
        return

    while True:
        # Implementa la lógica para crear, editar, borrar y visualizar contenedores
        print("\nOperaciones disponibles:")
        print("1. Crear contenedor")
        print("2. Editar contenedor")
        print("3. Borrar contenedor")
        print("4. Visualizar contenedor")
        print("5. Salir")
        choice = input("Selecciona una opción: ")

        if choice == "1":
            container_name = input("Nombre del contenedor: ")
            content = input("Contenido del contenedor: ")
            vault[container_name] = content
            save_vault(vault, key)
            print("Contenedor creado.")
        elif choice == "2":
            container_name = input("Nombre del contenedor a editar: ")
            if container_name in vault:
                content = input("Nuevo contenido del contenedor: ")
                vault[container_name] = content
                save_vault(vault, key)
                print("Contenedor editado.")
            else:
                print("El contenedor no existe.")
        elif choice == "3":
            container_name = input("Nombre del contenedor a borrar: ")
            if container_name in vault:
                del vault[container_name]
                save_vault(vault, key)
                print("Contenedor borrado.")
            else:
                print("El contenedor no existe.")
        elif choice == "4":
            container_name = input("Nombre del contenedor a visualizar: ")
            if container_name in vault:
                print(f"Contenido del contenedor '{container_name}':")
                print(vault[container_name])
            else:
                print("El contenedor no existe.")
        elif choice == "5":
            break
        else:
            print("Opción no válida. Por favor, intenta de nuevo.")

def save_vault(vault, key):
    """Guarda el vault cifrado en el archivo."""
    encrypted_data = encrypt_data(key, json.dumps(vault))
    storage.save_data(DATA_FILE, encrypted_data)

if __name__ == "__main__":
    main()
